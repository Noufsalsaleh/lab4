from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('', include('taxapp.urls')),
    path('admin/', admin.site.urls),
    path("taxapp/", include("taxapp.urls")),
]